<?php
/**
 * WPBakery Visual Composer shortcodes
 *
 * @package WPBakeryVisualComposer
 *
 */

class WPBakeryShortCode_VC_Wp_Search extends WPBakeryShortCode {
}

class WPBakeryShortCode_VC_Wp_Meta extends WPBakeryShortCode {
}

class WPBakeryShortCode_VC_Wp_Recentcomments extends WPBakeryShortCode {
}

class WPBakeryShortCode_VC_Wp_Calendar extends WPBakeryShortCode {
}

class WPBakeryShortCode_VC_Wp_Pages extends WPBakeryShortCode {
}

class WPBakeryShortCode_VC_Wp_Tagcloud extends WPBakeryShortCode {
}

class WPBakeryShortCode_VC_Wp_Custommenu extends WPBakeryShortCode {
}

class WPBakeryShortCode_VC_Wp_Text extends WPBakeryShortCode {
}

class WPBakeryShortCode_VC_Wp_Posts extends WPBakeryShortCode {
}

class WPBakeryShortCode_VC_Wp_Links extends WPBakeryShortCode {
}

class WPBakeryShortCode_VC_Wp_Categories extends WPBakeryShortCode {
}

class WPBakeryShortCode_VC_Wp_Archives extends WPBakeryShortCode {
}

class WPBakeryShortCode_VC_Wp_Rss extends WPBakeryShortCode {
}

?>